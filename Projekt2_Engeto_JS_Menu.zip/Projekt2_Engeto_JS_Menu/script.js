const menuIcon = document.querySelector (".menu-icon")
const menuList = document.querySelector ("nav")
const hamburgerIcon = document.querySelector (".fa-solid")



menuIcon.addEventListener ("click",() => {
    // při kliknuti, pokud je hamburger, pridej misto nej krizek a odeber burger, jinak nech burger a odeber krizek
    if (hamburgerIcon.classList[1]  === "fa-bars-staggered") {
        // classList[1] vybere pouze druhou class, ignorujeme fa-solid
        hamburgerIcon.classList.add("fa-xmark")
        hamburgerIcon.classList.remove("fa-bars-staggered")
        menuList.style.display = "block"

    } else {
        hamburgerIcon.classList.add ("fa-bars-staggered")
        hamburgerIcon.classList.remove ("fa-xmark")
        menuList.style.display = "none"

    }        
   
})